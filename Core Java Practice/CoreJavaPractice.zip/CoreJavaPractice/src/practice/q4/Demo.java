package practice.q4;

public class Demo { // Line 1
	public static void main(String[] args) { // Line 2
		byte var1 = 127; // Line 3
		byte var2 = 126; // Line 4
//		byte result = var1 + var2; // Line 5--won't compile
//		int result = var1 + var2; // Line 5

		byte result = (byte) (var1 + var2);

		byte var3 = 123;
		short var4 = 126;

//			short result2 = var3 + var4;//--won't compile

		short result2 = (short) (var3 + var4);
	}
}