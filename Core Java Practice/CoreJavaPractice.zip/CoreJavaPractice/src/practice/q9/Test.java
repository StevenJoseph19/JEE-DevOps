package practice.q9;

public class Test {
	public static void main(String args[]) {
		int x = 5;
		x *= 3 + 7;
		System.out.println(x);
	}
}