package practice.q5;

public class Demo { // Line 1
	public static void main(String[] args) { // Line 2
		
		// variable choice is declared and initialized here
		// below choices are valid
//		int choice = 20;
//		byte choice = 20;
//		short choice = 20;
		char choice = 20;
		switch (choice) {
		case 100:
			System.out.println("One hundred");
			break;
		case 20:
			System.out.println("Twenty");
			break;
		case 30:
			System.out.println("Thirty");
			break;
		}
	}
}