package practice.q8;

public class Test {
	public static void main(String args[]) {
		int x = 12;
		while (x < 10) {
			x--;
		}
		System.out.print(x); // line 7
	}
}