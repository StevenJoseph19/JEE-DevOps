package practice.q13;

enum EnumDemo {
	A
}

class Test {
	enum EnumD {
		B
	}
// will compile
//	enum EnumC {
//		D
//	}

	void my_method() {
//        enum EnumC { D } -- won't compile
	}
}