package com.mycompany.jpa;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.mycompany.jpa.airport.Passenger;
import com.mycompany.jpa.airport.Ticket;

public class Main {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hibernatejpa.m04.ex07");
		EntityManager em = emf.createEntityManager();

		em.getTransaction().begin();

		Passenger john = new Passenger("John Smith");

		Ticket ticket1 = new Ticket("AA1234");
		Ticket ticket2 = new Ticket("BB5678");

		john.addTicket(ticket1);
		john.addTicket(ticket2);
		
		john.addAttribute("VIP", "YES");
		john.addAttribute("FREQUENT FLYER", "YES");
		
		em.persist(john);

		em.getTransaction().commit();

		emf.close();
	}

}
