package com.wiredbrain.friends.services;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.wiredbrain.friends.model.Friend;

@Repository
public interface FriendService extends CrudRepository<Friend, Integer> {

}
