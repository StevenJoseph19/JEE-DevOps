package com.mycompany.conferenceapp.models;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.mycompany.conferenceapp.models.TicketType;
import com.mycompany.conferenceapp.repositories.SessionJpaRepository;
import com.mycompany.conferenceapp.repositories.SessionRepository;
import com.mycompany.conferenceapp.repositories.TicketTypeJpaRepository;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
public class TicketTypeTest {

    @Autowired
    private TicketTypeJpaRepository jpaRepository;

    @Test
    public void testJpaTrue() throws Exception {
        List<TicketType> types = jpaRepository.findByIncludesWorkshopTrue();
        assertTrue(types.size() > 0);
    }
}
