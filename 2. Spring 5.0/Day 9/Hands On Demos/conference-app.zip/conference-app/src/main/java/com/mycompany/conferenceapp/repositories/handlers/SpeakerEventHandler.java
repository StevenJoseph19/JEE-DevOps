package com.mycompany.conferenceapp.repositories.handlers;

import java.util.HashSet;

import javax.validation.ConstraintViolationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.rest.core.annotation.HandleBeforeCreate;
import org.springframework.data.rest.core.annotation.RepositoryEventHandler;
import org.springframework.stereotype.Component;

import com.mycompany.conferenceapp.models.Speaker;
import com.mycompany.conferenceapp.repositories.SpeakerJpaRepository;

@Component
@RepositoryEventHandler
public class SpeakerEventHandler {
	@Autowired
	private SpeakerJpaRepository repository;

	@HandleBeforeCreate
	public void handleSpeakerCreate(Speaker s) {

		// We want to enforce unique speaker first name
		Speaker foundSpeaker = repository.findFirstByFirstName(s.getFirstName());

		if (foundSpeaker != null) {
			System.out.println("First name needs to be unique");

			throw new ConstraintViolationException("First name needs to be unique", new HashSet<>());

		}

	}

}
