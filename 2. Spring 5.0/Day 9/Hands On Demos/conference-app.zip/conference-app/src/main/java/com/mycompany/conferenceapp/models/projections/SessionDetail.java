package com.mycompany.conferenceapp.models.projections;

import java.util.List;

import org.springframework.data.rest.core.config.Projection;

import com.mycompany.conferenceapp.models.Session;
import com.mycompany.conferenceapp.models.Speaker;

@Projection(name = "sessionDetail", types = { Session.class })
public interface SessionDetail {

	String getSessionName();

	String getSessionDescription();

	Integer getSessionLength();

	List<Speaker> getSpeakers();
}
