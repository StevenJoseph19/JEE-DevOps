package com.mycompany.conferenceapp.models.projections;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.rest.core.config.Projection;

import com.mycompany.conferenceapp.models.Session;
import com.mycompany.conferenceapp.models.Speaker;

@Projection(name = "sessionDetailView", types = { Session.class })
public interface SessionDetailView {

	@Value("#{target.sessionName}")
	String getTitle();

	String getSessionDescription();

	Integer getSessionLength();

	List<Speaker> getSpeakers();

	@Value("#{target.speakers.size()}")
	Integer getSpeakerCount();
}