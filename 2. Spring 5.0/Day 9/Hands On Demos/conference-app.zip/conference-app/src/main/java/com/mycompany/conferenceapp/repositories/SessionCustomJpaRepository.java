package com.mycompany.conferenceapp.repositories;

import java.util.List;

import com.mycompany.conferenceapp.models.Session;

public interface SessionCustomJpaRepository {
    List<Session> customGetSessions();
}
