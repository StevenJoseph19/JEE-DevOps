package com.mycompany.swagger2.data;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface JiraTaskRepository extends CrudRepository<JiraTask, Integer> {

	Iterable<JiraTask> findByBlocker(Boolean isBlocker);

}
